var frameWork = "React";
console.log("The framework is " + frameWork);

switch (frameWork){
    case "React":
        console.log("Javascript");
        break;

    case "Angular":
        console.log("typescript");
        break;
}
