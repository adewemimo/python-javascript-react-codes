var compareWithZero = function(number){
    if (number <= 0){
      return true;
    }
    else{
      return false;
    };
  
  }
  
  compareWithZero(5);
  compareWithZero(0);
  compareWithZero(-2);