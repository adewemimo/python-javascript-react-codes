var calculatePoints = function(numWins, numDraws, numLosses)
{
  return calPoint = numWins*3 + numDraws ;
}

calculatePoints(3, 4, 2);
calculatePoints(5, 0, 2);
calculatePoints(0, 0, 1);
