var a = 5;
var bol = true;
var text = "Test String"
console.log(a);
console.log(bol);
console.log(text);