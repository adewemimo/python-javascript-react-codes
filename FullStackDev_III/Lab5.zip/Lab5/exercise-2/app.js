const { writeData } = require('./writer.js');

writeData();



