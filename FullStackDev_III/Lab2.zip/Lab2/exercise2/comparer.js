exports.AreNumberEqual =  (num1, num2) => {
    this.num1 = num1;
    this.num2 = num2;
    if (this.num1 === this.num2) {
        return this.answer = true
    } 
    else{
        return this.answer = false
    }

}