var ft = require('./sportsteam');

// set modules property
ft.teamname = "Leafs";

// call module method
ft.cheer();
ft.Boo();
