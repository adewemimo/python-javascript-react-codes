let uc = require("upper-case");

console.log(uc.upperCase("string"));
let n = 0;
while (n < 10){
    console.log(`Hello World`);
    n++;
}