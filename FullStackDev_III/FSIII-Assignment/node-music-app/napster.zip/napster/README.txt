FullStack Development III - Assignment

Name: Oluwaseun Soetan(101339637)

Steps to running the program:

1. Open program folder in VisualStudio Code (VSC)
2. Open path to the program in VSC Terminal
3. Run "npm install" in the VSC Terminal to install dependencies
4. Create Database - NapsterApp and collections - downloadEvents and socketEvents in MongoDB Compass
5. Run program in using  $ node server.js or $ nodemon server.js
6. Run on the browser, the URL - localhost:3004 for view the client side of the program.

Thank you. 
