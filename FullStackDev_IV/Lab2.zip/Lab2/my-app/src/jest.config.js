module.exports = {
    setupFilesAfterEnv: ['./rtl.setup.js']
};