import UserList from "./studentList";
import React from 'react';
// import AddStudent from "./AddStudent";
// import DeleteStudent from "./DeleteStudent";

class App extends React.Component {
  render() { 
    return ( 
      <>
      {/* <AddStudent /> */}
      <UserList />
      {/* <DeleteStudent /> */}
      </>
     
     );
  }
}
 
export default App;
 
