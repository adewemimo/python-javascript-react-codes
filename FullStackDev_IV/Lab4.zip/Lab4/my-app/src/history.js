import createBrowserHistory from "history/createBrowserHistory";

const customHistory = createBrowserHistory();

export default customHistory;