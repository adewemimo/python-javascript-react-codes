import React from 'react';

const About = () => {
    return (
      <div>
        <p>About Us</p>
      </div>
    )
  }

  export default About;