import React from 'react';

const Contact = () => {
    return (
      <div>
        <p>Contact Us</p>
      </div>
    )
  }

  export default Contact;