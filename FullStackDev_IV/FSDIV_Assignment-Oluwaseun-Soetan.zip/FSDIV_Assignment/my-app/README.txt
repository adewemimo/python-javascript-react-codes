FullStack Development IV - Assignment

Name: Oluwaseun Soetan(101339637)

Steps to running the program:

1. Open program folder in VisualStudio Code (VSC)
2. Open path to the program in VSC Terminal
3. Run "npm install" in the VSC Terminal to install dependencies
4. Run "npm start" to run the program in the browser
5. Program will auto run in the browser at "npm start"

Thank you. 
