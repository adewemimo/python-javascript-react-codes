const LikeButton = () => {
    return <button>Like!</button>;
}
 
export default LikeButton;