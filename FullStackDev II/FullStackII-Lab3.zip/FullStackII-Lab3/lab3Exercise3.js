const reverselt = function(myArr){
    return myArr.reverse();
  }
  
reverselt([1,2,3,4]);
reverselt([9,9,2,3,4]);
reverselt([]);