const buildArray = function (num){
    var myArray = [];

    for (counter = 0; counter < num; counter++){
      myArray.push(counter);
    }
    return myArray;
}
  
buildArray(2);
buildArray(25);
  
  