//ES6 coding: filter method in use 
const values = [1, 60, 34, 30, 20, 5];
filterLessThan20 = values.filter(value => value < 20);
console.log(filterLessThan20);