const gretter = (myArray, counter)=>{
    for (let name of myArray){
      console.log(`Hello ${name}`);
    }
}
  
gretter(['Randy Savage', 'Ric Flair', 'Hulk Hogan'],3);