const isCCValid = (ccn) => ccn !== null && !Number.isNaN(parseInt(ccn)) && ccn.length > 13;

window.onload = console.log("window loaded..");

var orderObj = {
    creditCardNumber: "",
    expiryMonth: "",
    expiryYear: "",
    ccv: "",
};


const handleOrderClick = () => {
    console.log("order placed");

    orderObj.creditCardNumber = document.querySelector("#CreditCardNumber").value;
    orderObj.expiryMonth = document.querySelector("#ExpiryMonth").value;
    orderObj.expiryYear = document.querySelector("#ExpiryYears").value;
    orderObj.ccv = document.querySelector("#ccv").value;

    console.log(orderObj);
}


let placeOrder = document.querySelector("#continue-button");
placeOrder.addEventListener("click", handleOrderClick);






