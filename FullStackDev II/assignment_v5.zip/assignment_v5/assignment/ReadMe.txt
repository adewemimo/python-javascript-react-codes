Note on Full Stack Development II Assignment

Names of Team Members:1. Oluwaseun Soetan (Student ID: 101339637)2. Natasha Rupani (Student ID: 101339597)Instructions to run:1. Unzip Assignment_v52. Open MusicStreaming.html file using chrome browser3. The project uses bootstrap. Please ensure your system is connected to internet.

Some points to note:
- Searching song records will return song tiles not a table of records.
All information that is required on a song record as per the assignment guidelines are designed and placed in a song tile. 
- Album title and song ratings are on the album cover image. 
- Favourite button is a small heart image below the album cover photo.  
-The download button has a downward facing arrow and placed next to favourite button.
- Clicking on any song tile image will remove it from favourite section.

 Thank you.