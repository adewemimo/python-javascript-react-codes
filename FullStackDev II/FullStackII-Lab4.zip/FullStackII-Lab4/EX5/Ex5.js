const getDOMElements = function () {
    console.log(document.querySelector("#menu"));
    console.log(document.querySelectorAll(".item"));
    console.log(document.querySelectorAll('.highlight'));
    console.log(document.querySelector("readBtn"));
    console.log(document.querySelectorAll("h1"));
    console.log(document.querySelectorAll("h2"));
}

getDOMElements();